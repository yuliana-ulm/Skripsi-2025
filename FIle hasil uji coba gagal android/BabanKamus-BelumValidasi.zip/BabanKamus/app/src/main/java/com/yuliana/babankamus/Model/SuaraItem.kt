package com.yuliana.babankamus.Model

//data class SuaraItem(
//    val nama: String = "",
//    val suara_base64: String = ""
//)
