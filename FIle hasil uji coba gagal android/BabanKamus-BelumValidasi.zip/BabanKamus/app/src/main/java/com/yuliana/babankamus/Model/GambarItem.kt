package com.yuliana.babankamus.Model

//data class GambarItem(
//    val nama: String = "",
//    val gambar_base64: String = ""
//)
